package AccomodationLevel;

public interface LevelAccomodation {
	int calculatePrice(int baseprice);
}
