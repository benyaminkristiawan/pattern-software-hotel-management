package QualityRoom;

public interface RoomQuality {
	int calculatePrice(int baseprice);
}
